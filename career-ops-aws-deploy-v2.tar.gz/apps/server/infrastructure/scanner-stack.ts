import path from 'node:path';
import { fileURLToPath } from 'node:url';
import {
  CfnOutput,
  Duration,
  RemovalPolicy,
  Stack,
  type StackProps,
  aws_cloudwatch as cloudwatch,
  aws_dynamodb as dynamodb,
  aws_iam as iam,
  aws_lambda as lambda,
  aws_lambda_event_sources as eventSources,
  aws_lambda_nodejs as lambdaNodejs,
  aws_logs as logs,
  aws_scheduler as scheduler,
  aws_sqs as sqs,
  custom_resources as customResources
} from 'aws-cdk-lib';
import { Construct } from 'constructs';
import { developmentProfiles, developmentSources } from '../src/catalog.js';

export interface ScannerStackProps extends StackProps {
  stage?: string;
}

const directory = path.dirname(fileURLToPath(import.meta.url));

export class ScannerStack extends Stack {
  readonly sourcesTable: dynamodb.Table;
  readonly jobsTable: dynamodb.Table;
  readonly scanRunsTable: dynamodb.Table;
  readonly scanQueue: sqs.Queue;
  readonly deadLetterQueue: sqs.Queue;
  readonly worker: lambdaNodejs.NodejsFunction;
  readonly profilesTable: dynamodb.Table;
  readonly recommendationsTable: dynamodb.Table;
  readonly feedbackEventsTable: dynamodb.Table;
  readonly enrichmentCacheTable: dynamodb.Table;
  readonly enrichmentBudgetsTable: dynamodb.Table;
  readonly enrichmentQueue: sqs.Queue;
  readonly enrichmentDeadLetterQueue: sqs.Queue;
  readonly matchingDeadLetterQueue: sqs.Queue;
  readonly matchingWorker: lambdaNodejs.NodejsFunction;
  readonly enrichmentWorker: lambdaNodejs.NodejsFunction;

  constructor(scope: Construct, id: string, props: ScannerStackProps = {}) {
    super(scope, id, props);
    const stage = props.stage ?? 'dev';
    const production = stage === 'prod';
    const removalPolicy = production ? RemovalPolicy.RETAIN : RemovalPolicy.DESTROY;

    this.sourcesTable = new dynamodb.Table(this, 'SourcesTable', {
      tableName: `CareerOps-${capitalize(stage)}-Sources`,
      partitionKey: { name: 'sourceId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });

    this.jobsTable = new dynamodb.Table(this, 'JobsTable', {
      tableName: `CareerOps-${capitalize(stage)}-Jobs`,
      partitionKey: { name: 'jobKey', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy,
      stream: dynamodb.StreamViewType.NEW_AND_OLD_IMAGES
    });
    this.jobsTable.addGlobalSecondaryIndex({
      indexName: 'CanonicalUrlIndex',
      partitionKey: { name: 'canonicalUrlHash', type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL
    });

    this.scanRunsTable = new dynamodb.Table(this, 'ScanRunsTable', {
      tableName: `CareerOps-${capitalize(stage)}-ScanRuns`,
      partitionKey: { name: 'sourceId', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'startedAt', type: dynamodb.AttributeType.STRING },
      timeToLiveAttribute: 'expiresAt',
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });

    this.profilesTable = new dynamodb.Table(this, 'ProfilesTable', {
      tableName: `CareerOps-${capitalize(stage)}-UserProfiles`,
      partitionKey: { name: 'userId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });
    this.recommendationsTable = new dynamodb.Table(this, 'RecommendationsTable', {
      tableName: `CareerOps-${capitalize(stage)}-Recommendations`,
      partitionKey: { name: 'userId', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'recommendationId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });
    this.recommendationsTable.addGlobalSecondaryIndex({
      indexName: 'JobRecommendationsIndex',
      partitionKey: { name: 'jobKey', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'updatedAt', type: dynamodb.AttributeType.STRING },
      projectionType: dynamodb.ProjectionType.ALL
    });
    this.feedbackEventsTable = new dynamodb.Table(this, 'FeedbackEventsTable', {
      tableName: `CareerOps-${capitalize(stage)}-FeedbackEvents`,
      partitionKey: { name: 'userId', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'eventId', type: dynamodb.AttributeType.STRING },
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });
    this.enrichmentCacheTable = new dynamodb.Table(this, 'EnrichmentCacheTable', {
      tableName: `CareerOps-${capitalize(stage)}-EnrichmentCache`,
      partitionKey: { name: 'cacheKey', type: dynamodb.AttributeType.STRING },
      timeToLiveAttribute: 'expiresAt',
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });
    this.enrichmentBudgetsTable = new dynamodb.Table(this, 'EnrichmentBudgetsTable', {
      tableName: `CareerOps-${capitalize(stage)}-EnrichmentBudgets`,
      partitionKey: { name: 'userDate', type: dynamodb.AttributeType.STRING },
      timeToLiveAttribute: 'expiresAt',
      billingMode: dynamodb.BillingMode.PAY_PER_REQUEST,
      encryption: dynamodb.TableEncryption.AWS_MANAGED,
      deletionProtection: production,
      removalPolicy
    });

    this.deadLetterQueue = new sqs.Queue(this, 'ScanDeadLetterQueue', {
      queueName: `career-ops-${stage}-scan-dlq`,
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      retentionPeriod: Duration.days(14),
      enforceSSL: true
    });
    this.scanQueue = new sqs.Queue(this, 'ScanQueue', {
      queueName: `career-ops-${stage}-scan`,
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      visibilityTimeout: Duration.minutes(3),
      retentionPeriod: Duration.days(4),
      enforceSSL: true,
      deadLetterQueue: {
        queue: this.deadLetterQueue,
        maxReceiveCount: 5
      }
    });
    this.enrichmentDeadLetterQueue = new sqs.Queue(this, 'EnrichmentDeadLetterQueue', {
      queueName: `career-ops-${stage}-enrichment-dlq`,
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      retentionPeriod: Duration.days(14),
      enforceSSL: true
    });
    this.enrichmentQueue = new sqs.Queue(this, 'EnrichmentQueue', {
      queueName: `career-ops-${stage}-enrichment`,
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      visibilityTimeout: Duration.minutes(2),
      retentionPeriod: Duration.days(4),
      enforceSSL: true,
      deadLetterQueue: {
        queue: this.enrichmentDeadLetterQueue,
        maxReceiveCount: 5
      }
    });
    this.matchingDeadLetterQueue = new sqs.Queue(this, 'MatchingDeadLetterQueue', {
      queueName: `career-ops-${stage}-matching-dlq`,
      encryption: sqs.QueueEncryption.SQS_MANAGED,
      retentionPeriod: Duration.days(14),
      enforceSSL: true
    });

    const workerLogGroup = new logs.LogGroup(this, 'WorkerLogGroup', {
      logGroupName: `/aws/lambda/career-ops-${stage}-scan-worker`,
      retention: production ? logs.RetentionDays.THREE_MONTHS : logs.RetentionDays.ONE_MONTH,
      removalPolicy
    });
    this.worker = new lambdaNodejs.NodejsFunction(this, 'ScanWorker', {
      functionName: `career-ops-${stage}-scan-worker`,
      entry: path.resolve(directory, '..', 'src', 'handler.ts'),
      handler: 'handler',
      runtime: lambda.Runtime.NODEJS_22_X,
      timeout: Duration.minutes(2),
      memorySize: 1024,
      logGroup: workerLogGroup,
      environment: {
        SOURCES_TABLE: this.sourcesTable.tableName,
        JOBS_TABLE: this.jobsTable.tableName,
        SCAN_RUNS_TABLE: this.scanRunsTable.tableName
      },
      bundling: {
        minify: true,
        sourceMap: true,
        target: 'node22',
        externalModules: ['@aws-sdk/*']
      }
    });
    this.worker.addEventSource(new eventSources.SqsEventSource(this.scanQueue, {
      batchSize: 1,
      reportBatchItemFailures: true,
      maxConcurrency: 2
    }));
    this.sourcesTable.grantReadWriteData(this.worker);
    this.jobsTable.grantReadWriteData(this.worker);
    this.scanRunsTable.grantReadWriteData(this.worker);

    this.matchingWorker = new lambdaNodejs.NodejsFunction(this, 'MatchingWorker', {
      functionName: `career-ops-${stage}-matching-worker`,
      entry: path.resolve(directory, '..', 'src', 'matching-handler.ts'),
      handler: 'handler',
      runtime: lambda.Runtime.NODEJS_22_X,
      timeout: Duration.minutes(2),
      memorySize: 1024,
      environment: {
        JOBS_TABLE: this.jobsTable.tableName,
        PROFILES_TABLE: this.profilesTable.tableName,
        RECOMMENDATIONS_TABLE: this.recommendationsTable.tableName,
        ENRICHMENT_CACHE_TABLE: this.enrichmentCacheTable.tableName,
        ENRICHMENT_BUDGETS_TABLE: this.enrichmentBudgetsTable.tableName,
        ENRICHMENT_QUEUE_URL: this.enrichmentQueue.queueUrl
      },
      bundling: {
        minify: true,
        sourceMap: true,
        target: 'node22',
        externalModules: ['@aws-sdk/*']
      }
    });
    this.matchingWorker.addEventSource(new eventSources.DynamoEventSource(this.jobsTable, {
      startingPosition: lambda.StartingPosition.LATEST,
      batchSize: 10,
      bisectBatchOnError: true,
      retryAttempts: 3,
      reportBatchItemFailures: true,
      onFailure: new eventSources.SqsDlq(this.matchingDeadLetterQueue)
    }));
    this.jobsTable.grantReadData(this.matchingWorker);
    this.profilesTable.grantReadData(this.matchingWorker);
    this.recommendationsTable.grantReadWriteData(this.matchingWorker);
    this.enrichmentCacheTable.grantReadData(this.matchingWorker);
    this.enrichmentBudgetsTable.grantReadWriteData(this.matchingWorker);
    this.enrichmentQueue.grantSendMessages(this.matchingWorker);

    this.enrichmentWorker = new lambdaNodejs.NodejsFunction(this, 'EnrichmentWorker', {
      functionName: `career-ops-${stage}-enrichment-worker`,
      entry: path.resolve(directory, '..', 'src', 'enrichment-handler.ts'),
      handler: 'handler',
      runtime: lambda.Runtime.NODEJS_22_X,
      timeout: Duration.minutes(1),
      memorySize: 1024,
      environment: {
        JOBS_TABLE: this.jobsTable.tableName,
        PROFILES_TABLE: this.profilesTable.tableName,
        RECOMMENDATIONS_TABLE: this.recommendationsTable.tableName,
        ENRICHMENT_CACHE_TABLE: this.enrichmentCacheTable.tableName,
        ENRICHMENT_BUDGETS_TABLE: this.enrichmentBudgetsTable.tableName,
        BEDROCK_MODEL_ID: 'amazon.nova-lite-v1:0'
      },
      bundling: {
        minify: true,
        sourceMap: true,
        target: 'node22',
        externalModules: ['@aws-sdk/*']
      }
    });
    this.enrichmentWorker.addEventSource(new eventSources.SqsEventSource(this.enrichmentQueue, {
      batchSize: 1,
      reportBatchItemFailures: true,
      maxConcurrency: 2
    }));
    this.jobsTable.grantReadData(this.enrichmentWorker);
    this.profilesTable.grantReadData(this.enrichmentWorker);
    this.recommendationsTable.grantReadWriteData(this.enrichmentWorker);
    this.enrichmentCacheTable.grantReadWriteData(this.enrichmentWorker);
    this.enrichmentWorker.addToRolePolicy(new iam.PolicyStatement({
      actions: ['bedrock:InvokeModel'],
      resources: ['*']
    }));

    const schedulerRole = new iam.Role(this, 'SchedulerRole', {
      assumedBy: new iam.ServicePrincipal('scheduler.amazonaws.com')
    });
    this.scanQueue.grantSendMessages(schedulerRole);
    this.deadLetterQueue.grantSendMessages(schedulerRole);

    for (const source of developmentSources.filter((item) => item.enabled)) {
      const seed = new customResources.AwsCustomResource(this, `Seed-${source.sourceId}`, {
        onCreate: {
          service: 'DynamoDB',
          action: 'putItem',
          parameters: {
            TableName: this.sourcesTable.tableName,
            Item: toAttributeMap(source),
            ConditionExpression: 'attribute_not_exists(sourceId)'
          },
          physicalResourceId: customResources.PhysicalResourceId.of(`source-${source.sourceId}`)
        },
        onUpdate: {
          service: 'DynamoDB',
          action: 'updateItem',
          parameters: {
            TableName: this.sourcesTable.tableName,
            Key: { sourceId: { S: source.sourceId } },
            UpdateExpression: [
              'SET provider = :provider',
              'company = :company',
              'boardUrl = :boardUrl',
              'boardIdentifier = :boardIdentifier',
              'cadenceMinutes = :cadenceMinutes',
              'priority = :priority',
              'enabled = :enabled'
            ].join(', '),
            ExpressionAttributeValues: {
              ':provider': toAttribute(source.provider),
              ':company': toAttribute(source.company),
              ':boardUrl': toAttribute(source.boardUrl),
              ':boardIdentifier': toAttribute(source.boardIdentifier),
              ':cadenceMinutes': toAttribute(source.cadenceMinutes),
              ':priority': toAttribute(source.priority),
              ':enabled': toAttribute(source.enabled)
            }
          },
          physicalResourceId: customResources.PhysicalResourceId.of(`source-${source.sourceId}`)
        },
        policy: customResources.AwsCustomResourcePolicy.fromSdkCalls({
          resources: [this.sourcesTable.tableArn]
        }),
        installLatestAwsSdk: false
      });
      seed.node.addDependency(this.sourcesTable);

      new scheduler.CfnSchedule(this, `Schedule-${source.sourceId}`, {
        name: `career-ops-${stage}-${source.sourceId}`,
        description: `Scan ${source.company} through ${source.provider}`,
        scheduleExpression: `rate(${source.cadenceMinutes} minutes)`,
        state: 'ENABLED',
        flexibleTimeWindow: {
          mode: 'FLEXIBLE',
          maximumWindowInMinutes: 5
        },
        target: {
          arn: this.scanQueue.queueArn,
          roleArn: schedulerRole.roleArn,
          input: JSON.stringify({
            sourceId: source.sourceId,
            provider: source.provider,
            scheduledAt: '<aws.scheduler.scheduled-time>',
            attempt: 0,
            correlationId: '<aws.scheduler.execution-id>'
          }),
          retryPolicy: {
            maximumEventAgeInSeconds: 3600,
            maximumRetryAttempts: 5
          },
          deadLetterConfig: { arn: this.deadLetterQueue.queueArn }
        }
      });
    }

    for (const profile of developmentProfiles) {
      const seed = new customResources.AwsCustomResource(this, `SeedProfile-${profile.userId}`, {
        onCreate: {
          service: 'DynamoDB',
          action: 'putItem',
          parameters: {
            TableName: this.profilesTable.tableName,
            Item: toAttributeMap(profile),
            ConditionExpression: 'attribute_not_exists(userId)'
          },
          physicalResourceId: customResources.PhysicalResourceId.of(`profile-${profile.userId}`)
        },
        policy: customResources.AwsCustomResourcePolicy.fromSdkCalls({
          resources: [this.profilesTable.tableArn]
        }),
        installLatestAwsSdk: false
      });
      seed.node.addDependency(this.profilesTable);
    }

    this.addObservability(stage);

    new CfnOutput(this, 'ScanQueueUrl', { value: this.scanQueue.queueUrl });
    new CfnOutput(this, 'SourcesTableName', { value: this.sourcesTable.tableName });
    new CfnOutput(this, 'JobsTableName', { value: this.jobsTable.tableName });
    new CfnOutput(this, 'RecommendationsTableName', { value: this.recommendationsTable.tableName });
  }

  private addObservability(stage: string): void {
    const dlqAlarm = new cloudwatch.Alarm(this, 'DlqMessagesAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-DLQ-Messages`,
      metric: this.deadLetterQueue.metricApproximateNumberOfMessagesVisible(),
      threshold: 1,
      evaluationPeriods: 1
    });
    const workerErrorAlarm = new cloudwatch.Alarm(this, 'WorkerErrorsAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-Worker-Errors`,
      metric: this.worker.metricErrors({ period: Duration.minutes(5) }),
      threshold: 1,
      evaluationPeriods: 1
    });
    const throttlesAlarm = new cloudwatch.Alarm(this, 'WorkerThrottlesAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-Worker-Throttles`,
      metric: this.worker.metricThrottles({ period: Duration.minutes(5) }),
      threshold: 1,
      evaluationPeriods: 1
    });
    const queueAgeAlarm = new cloudwatch.Alarm(this, 'QueueAgeAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-Queue-Age`,
      metric: this.scanQueue.metricApproximateAgeOfOldestMessage(),
      threshold: 600,
      evaluationPeriods: 2
    });
    const matchingDlqAlarm = new cloudwatch.Alarm(this, 'MatchingDlqAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-Matching-DLQ`,
      metric: this.matchingDeadLetterQueue.metricApproximateNumberOfMessagesVisible(),
      threshold: 1,
      evaluationPeriods: 1
    });
    const enrichmentDlqAlarm = new cloudwatch.Alarm(this, 'EnrichmentDlqAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-Enrichment-DLQ`,
      metric: this.enrichmentDeadLetterQueue.metricApproximateNumberOfMessagesVisible(),
      threshold: 1,
      evaluationPeriods: 1
    });
    const enrichmentErrorAlarm = new cloudwatch.Alarm(this, 'EnrichmentErrorsAlarm', {
      alarmName: `CareerOps-${capitalize(stage)}-Enrichment-Errors`,
      metric: this.enrichmentWorker.metricErrors({ period: Duration.minutes(5) }),
      threshold: 1,
      evaluationPeriods: 1
    });

    const dashboard = new cloudwatch.Dashboard(this, 'ScannerDashboard', {
      dashboardName: `CareerOps-${capitalize(stage)}-Scanner`
    });
    dashboard.addWidgets(
      new cloudwatch.GraphWidget({
        title: 'Scan throughput',
        left: [
          metric('Scans'),
          metric('JobsInserted'),
          metric('JobsUpdated'),
          metric('ScanFailures')
        ]
      }),
      new cloudwatch.GraphWidget({
        title: 'Scan duration',
        left: [metric('ScanDuration', 'Milliseconds')]
      }),
      new cloudwatch.GraphWidget({
        title: 'Queue health',
        left: [
          this.scanQueue.metricApproximateNumberOfMessagesVisible(),
          this.scanQueue.metricApproximateAgeOfOldestMessage(),
          this.deadLetterQueue.metricApproximateNumberOfMessagesVisible()
        ]
      }),
      new cloudwatch.AlarmWidget({ title: 'DLQ', alarm: dlqAlarm }),
      new cloudwatch.AlarmWidget({ title: 'Worker errors', alarm: workerErrorAlarm }),
      new cloudwatch.AlarmWidget({ title: 'Worker throttles', alarm: throttlesAlarm }),
      new cloudwatch.AlarmWidget({ title: 'Queue age', alarm: queueAgeAlarm }),
      new cloudwatch.AlarmWidget({ title: 'Matching DLQ', alarm: matchingDlqAlarm }),
      new cloudwatch.AlarmWidget({ title: 'Enrichment DLQ', alarm: enrichmentDlqAlarm }),
      new cloudwatch.AlarmWidget({ title: 'Enrichment errors', alarm: enrichmentErrorAlarm })
    );
  }
}

function metric(name: string, unit = 'Count'): cloudwatch.Metric {
  return new cloudwatch.Metric({
    namespace: 'CareerOps/Scanner',
    metricName: name,
    statistic: 'Sum',
    period: Duration.minutes(5),
    unit: unit === 'Milliseconds' ? cloudwatch.Unit.MILLISECONDS : cloudwatch.Unit.COUNT
  });
}

function capitalize(value: string): string {
  return value.charAt(0).toUpperCase() + value.slice(1);
}

function toAttributeMap(value: Record<string, unknown>): Record<string, unknown> {
  return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, toAttribute(item)]));
}

function toAttribute(value: unknown): Record<string, unknown> {
  if (typeof value === 'string') return { S: value };
  if (typeof value === 'number') return { N: String(value) };
  if (typeof value === 'boolean') return { BOOL: value };
  if (Array.isArray(value)) return { L: value.map(toAttribute) };
  if (value && typeof value === 'object') return { M: toAttributeMap(value as Record<string, unknown>) };
  return { NULL: true };
}
