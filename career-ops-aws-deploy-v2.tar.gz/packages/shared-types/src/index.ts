import { z } from 'zod';

export const ProviderIdSchema = z.enum([
  'greenhouse',
  'ashby',
  'lever',
  'workable',
  'smartrecruiters',
  'recruitee'
]);
export type ProviderId = z.infer<typeof ProviderIdSchema>;

export const SourceHealthSchema = z.enum(['healthy', 'degraded', 'failing', 'disabled']);
export type SourceHealth = z.infer<typeof SourceHealthSchema>;

export const SourcePrioritySchema = z.enum(['high', 'normal', 'low']);
export const WorkModeSchema = z.enum(['remote', 'hybrid', 'onsite', 'unknown']);
export const JobStatusSchema = z.enum(['active', 'inactive']);
export const ScanRunStatusSchema = z.enum(['running', 'succeeded', 'failed', 'skipped']);
export const ScoreBandSchema = z.enum(['strong', 'good', 'possible', 'low']);
export type ScoreBand = z.infer<typeof ScoreBandSchema>;
export const RecommendationStatusSchema = z.enum(['recommended', 'dismissed', 'not_interested', 'evaluated', 'applied']);
export const ExplanationStatusSchema = z.enum(['deterministic', 'pending', 'enriched', 'failed']);
export const FeedbackActionSchema = z.enum(['saved', 'dismissed', 'not_interested', 'evaluated', 'applied', 'restored']);

const IsoDateSchema = z.string().datetime({ offset: true });
const CorrelationIdSchema = z.string().trim().min(8).max(200).regex(/^[A-Za-z0-9._:-]+$/);
const HttpUrlSchema = z.string().url().refine((value) => {
  const protocol = new URL(value).protocol;
  return protocol === 'https:' || protocol === 'http:';
}, 'URL must use HTTP or HTTPS');

export const CompensationSchema = z.object({
  currency: z.string().trim().length(3).transform((value) => value.toUpperCase()),
  min: z.number().nonnegative().optional(),
  max: z.number().nonnegative().optional(),
  interval: z.enum(['hour', 'day', 'week', 'month', 'year']).optional(),
  text: z.string().trim().optional()
}).superRefine((value, context) => {
  if (value.min !== undefined && value.max !== undefined && value.min > value.max) {
    context.addIssue({ code: 'custom', message: 'Compensation minimum cannot exceed maximum' });
  }
});
export type Compensation = z.infer<typeof CompensationSchema>;

export const JobSourceSchema = z.object({
  sourceId: z.string().trim().min(3).max(120).regex(/^[a-z0-9][a-z0-9-]*$/),
  provider: ProviderIdSchema,
  company: z.string().trim().min(1).max(200),
  boardUrl: z.string().url(),
  boardIdentifier: z.string().trim().min(1).max(300),
  cadenceMinutes: z.number().int().min(5).max(1440),
  priority: SourcePrioritySchema.default('normal'),
  enabled: z.boolean().default(true),
  health: SourceHealthSchema.default('healthy'),
  lastScanAt: IsoDateSchema.optional(),
  nextScanAt: IsoDateSchema.optional(),
  consecutiveFailures: z.number().int().nonnegative().default(0),
  latestError: z.string().max(2000).optional(),
  leaseOwner: z.string().max(200).optional(),
  leaseExpiresAt: IsoDateSchema.optional()
});
export type JobSource = z.infer<typeof JobSourceSchema>;

export const ScanTaskSchema = z.object({
  sourceId: z.string().trim().min(3).max(120),
  provider: ProviderIdSchema,
  scheduledAt: IsoDateSchema,
  attempt: z.number().int().nonnegative().default(0),
  correlationId: CorrelationIdSchema
});
export type ScanTask = z.infer<typeof ScanTaskSchema>;

export const NormalizedJobSchema = z.object({
  provider: ProviderIdSchema,
  providerJobId: z.string().trim().min(1).max(500),
  sourceId: z.string().trim().min(3).max(120),
  canonicalUrl: HttpUrlSchema,
  company: z.string().trim().min(1).max(200),
  title: z.string().trim().min(1).max(500),
  description: z.string().default(''),
  locations: z.array(z.string().trim().min(1).max(300)).default([]),
  workMode: WorkModeSchema.default('unknown'),
  compensation: CompensationSchema.optional(),
  postedAt: IsoDateSchema.optional(),
  firstSeenAt: IsoDateSchema,
  lastSeenAt: IsoDateSchema,
  lastVerifiedAt: IsoDateSchema.optional(),
  status: JobStatusSchema.default('active'),
  contentHash: z.string().regex(/^[a-f0-9]{64}$/)
});
export type NormalizedJob = z.infer<typeof NormalizedJobSchema>;

export const StoredJobSchema = NormalizedJobSchema.extend({
  jobKey: z.string().min(3),
  canonicalUrlHash: z.string().regex(/^[a-f0-9]{64}$/),
  sourceIds: z.preprocess(
    (value) => value instanceof Set ? [...value] : value,
    z.array(z.string().min(3)).min(1)
  )
});
export type StoredJob = z.infer<typeof StoredJobSchema>;

export const FeedbackAffinitySchema = z.object({
  roles: z.record(z.string(), z.number().min(-1).max(1)).default({}),
  companies: z.record(z.string(), z.number().min(-1).max(1)).default({}),
  skills: z.record(z.string(), z.number().min(-1).max(1)).default({}),
  locations: z.record(z.string(), z.number().min(-1).max(1)).default({}),
  workModes: z.record(z.string(), z.number().min(-1).max(1)).default({})
});
export type FeedbackAffinity = z.infer<typeof FeedbackAffinitySchema>;

export const UserMatchingProfileSchema = z.object({
  userId: z.string().trim().min(1).max(200),
  profileVersion: z.number().int().positive(),
  active: z.boolean().default(true),
  targetRoles: z.array(z.string().trim().min(1).max(200)).min(1),
  excludedTitles: z.array(z.string().trim().min(1).max(200)).default([]),
  skills: z.array(z.string().trim().min(1).max(120)).default([]),
  evidenceKeywords: z.array(z.string().trim().min(1).max(120)).default([]),
  careerGoals: z.array(z.string().trim().min(1).max(300)).default([]),
  targetLocations: z.array(z.string().trim().min(1).max(200)).default([]),
  authorizedLocations: z.array(z.string().trim().min(1).max(200)).default([]),
  acceptedWorkModes: z.array(WorkModeSchema).min(1).default(['remote', 'hybrid', 'onsite', 'unknown']),
  acceptedSeniorities: z.array(z.enum(['intern', 'entry', 'mid', 'senior', 'staff', 'principal', 'lead', 'manager', 'director', 'executive', 'unknown']))
    .min(1)
    .default(['entry', 'mid', 'senior', 'staff', 'principal', 'lead', 'manager', 'director', 'unknown']),
  minimumCompensation: CompensationSchema.optional(),
  maxPostingAgeDays: z.number().int().positive().max(365).optional(),
  feedbackAffinity: FeedbackAffinitySchema.default({
    roles: {},
    companies: {},
    skills: {},
    locations: {},
    workModes: {}
  }),
  enrichmentDailyLimit: z.number().int().nonnegative().max(100).default(10),
  updatedAt: IsoDateSchema
});
export type UserMatchingProfile = z.infer<typeof UserMatchingProfileSchema>;

export const ScoreBreakdownSchema = z.object({
  skillsEvidence: z.number().min(0).max(30),
  targetRole: z.number().min(0).max(20),
  careerGoals: z.number().min(0).max(15),
  locationWorkMode: z.number().min(0).max(15),
  compensation: z.number().min(0).max(10),
  feedbackAffinity: z.number().min(0).max(10)
});
export type ScoreBreakdown = z.infer<typeof ScoreBreakdownSchema>;

export const RecommendationSchema = z.object({
  userId: z.string().trim().min(1).max(200),
  recommendationId: z.string().trim().min(3).max(800),
  jobKey: z.string().trim().min(3).max(800),
  profileVersion: z.number().int().positive(),
  jobContentHash: z.string().regex(/^[a-f0-9]{64}$/),
  fitScore: z.number().int().min(0).max(100),
  scoreBand: ScoreBandSchema,
  scoreBreakdown: ScoreBreakdownSchema,
  eligible: z.boolean(),
  eligibilityReasons: z.array(z.string().max(500)).default([]),
  strongMatches: z.array(z.string().max(500)).default([]),
  concerns: z.array(z.string().max(500)).default([]),
  applicationAngles: z.array(z.string().max(500)).default([]),
  explanationStatus: ExplanationStatusSchema.default('deterministic'),
  status: RecommendationStatusSchema.default('recommended'),
  saved: z.boolean().default(false),
  hiddenByDefault: z.boolean(),
  rankTieBreaker: z.number().int().nonnegative(),
  createdAt: IsoDateSchema,
  updatedAt: IsoDateSchema
});
export type Recommendation = z.infer<typeof RecommendationSchema>;

export const FeedbackEventSchema = z.object({
  userId: z.string().trim().min(1).max(200),
  eventId: z.string().trim().min(8).max(200),
  recommendationId: z.string().trim().min(3).max(800),
  jobKey: z.string().trim().min(3).max(800),
  action: FeedbackActionSchema,
  dimensions: z.object({
    role: z.string().optional(),
    company: z.string().optional(),
    skills: z.array(z.string()).default([]),
    locations: z.array(z.string()).default([]),
    workMode: WorkModeSchema.optional()
  }),
  weight: z.number().min(-1).max(1),
  createdAt: IsoDateSchema
});
export type FeedbackEvent = z.infer<typeof FeedbackEventSchema>;

export const MatchJobTaskSchema = z.object({
  jobKey: z.string().trim().min(3).max(800),
  contentHash: z.string().regex(/^[a-f0-9]{64}$/),
  correlationId: CorrelationIdSchema
});
export type MatchJobTask = z.infer<typeof MatchJobTaskSchema>;

export const EnrichmentTaskSchema = z.object({
  userId: z.string().trim().min(1).max(200),
  recommendationId: z.string().trim().min(3).max(800),
  jobKey: z.string().trim().min(3).max(800),
  profileVersion: z.number().int().positive(),
  jobContentHash: z.string().regex(/^[a-f0-9]{64}$/),
  cacheKey: z.string().trim().min(3).max(800),
  correlationId: CorrelationIdSchema
});
export type EnrichmentTask = z.infer<typeof EnrichmentTaskSchema>;

export const EnrichmentOutputSchema = z.object({
  strongMatches: z.array(z.string().trim().min(1).max(500)).min(1).max(5),
  concerns: z.array(z.string().trim().min(1).max(500)).max(5).default([]),
  applicationAngles: z.array(z.string().trim().min(1).max(500)).max(5).default([])
});
export type EnrichmentOutput = z.infer<typeof EnrichmentOutputSchema>;

export const ScanErrorSchema = z.object({
  code: z.string().min(1).max(120),
  message: z.string().min(1).max(2000),
  retryable: z.boolean(),
  providerJobId: z.string().optional()
});
export type ScanError = z.infer<typeof ScanErrorSchema>;

export const ScanResultSchema = z.object({
  inserted: z.number().int().nonnegative(),
  updated: z.number().int().nonnegative(),
  unchanged: z.number().int().nonnegative(),
  rejected: z.number().int().nonnegative(),
  failed: z.number().int().nonnegative(),
  errors: z.array(ScanErrorSchema).default([])
});
export type ScanResult = z.infer<typeof ScanResultSchema>;

export const ScanRunSchema = z.object({
  sourceId: z.string().trim().min(3).max(120),
  startedAt: IsoDateSchema,
  completedAt: IsoDateSchema.optional(),
  correlationId: CorrelationIdSchema,
  provider: ProviderIdSchema,
  status: ScanRunStatusSchema,
  durationMs: z.number().int().nonnegative().optional(),
  result: ScanResultSchema,
  error: ScanErrorSchema.optional(),
  expiresAt: z.number().int().positive()
});
export type ScanRun = z.infer<typeof ScanRunSchema>;

export function parseJobSource(input: unknown): JobSource {
  return JobSourceSchema.parse(input);
}

export function parseScanTask(input: unknown): ScanTask {
  return ScanTaskSchema.parse(input);
}

export function parseNormalizedJob(input: unknown): NormalizedJob {
  return NormalizedJobSchema.parse(input);
}

export function parseUserMatchingProfile(input: unknown): UserMatchingProfile {
  return UserMatchingProfileSchema.parse(input);
}

export function parseRecommendation(input: unknown): Recommendation {
  return RecommendationSchema.parse(input);
}

export function parseMatchJobTask(input: unknown): MatchJobTask {
  return MatchJobTaskSchema.parse(input);
}

export function parseEnrichmentTask(input: unknown): EnrichmentTask {
  return EnrichmentTaskSchema.parse(input);
}
