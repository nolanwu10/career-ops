import { createHash } from 'node:crypto';
import { parseNormalizedJob, type Compensation, type JobSource, type NormalizedJob } from '@career-ops/shared-types';
import type { ProviderJob } from './types.js';

const TRACKING_PARAMS = new Set([
  'gh_src', 'source', 'ref', 'referrer', 'utm_campaign', 'utm_content',
  'utm_medium', 'utm_source', 'utm_term'
]);

export function canonicalizeJobUrl(input: string): string {
  const url = new URL(input);
  if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('Job URL must use HTTP or HTTPS');
  url.hash = '';
  for (const key of [...url.searchParams.keys()]) {
    if (TRACKING_PARAMS.has(key.toLowerCase())) url.searchParams.delete(key);
  }
  url.hostname = url.hostname.toLowerCase();
  url.pathname = url.pathname.replace(/\/+/g, '/').replace(/\/$/, '') || '/';
  const sorted = [...url.searchParams.entries()].sort(([a], [b]) => a.localeCompare(b));
  url.search = '';
  for (const [key, value] of sorted) url.searchParams.append(key, value);
  return url.toString();
}

export function normalizeLocations(values: string[] = []): string[] {
  const locations = values
    .flatMap((value) => String(value || '').split(/\s*[;|]\s*/))
    .map((value) => value.replace(/\s+/g, ' ').trim())
    .filter(Boolean);
  return [...new Map(locations.map((value) => [value.toLowerCase(), value])).values()];
}

export function inferWorkMode(locations: string[], explicit?: NormalizedJob['workMode']): NormalizedJob['workMode'] {
  if (explicit && explicit !== 'unknown') return explicit;
  const text = locations.join(' ').toLowerCase();
  if (/\bhybrid\b/.test(text)) return 'hybrid';
  if (/\bremote\b|anywhere/.test(text)) return 'remote';
  if (/\bon[- ]?site\b|\boffice\b/.test(text)) return 'onsite';
  return 'unknown';
}

export function parseCompensationText(text: string | undefined): Compensation | undefined {
  const raw = String(text || '').replace(/\s+/g, ' ').trim();
  if (!raw) return undefined;
  const currency = /\bEUR\b|€/.test(raw) ? 'EUR'
    : /\bGBP\b|£/.test(raw) ? 'GBP'
      : /\bCAD\b/.test(raw) ? 'CAD'
        : 'USD';
  const interval = /\/\s*(?:hr|hour)|per hour/i.test(raw) ? 'hour'
    : /\/\s*month|per month/i.test(raw) ? 'month'
      : /\/\s*week|per week/i.test(raw) ? 'week'
        : /\/\s*day|per day/i.test(raw) ? 'day'
          : 'year';
  const numbers = [...raw.matchAll(/(?:[$€£]\s*)?(\d[\d,.]*)(\s*[kK])?/g)]
    .map((match) => Number(match[1]?.replaceAll(',', '')) * (match[2] ? 1000 : 1))
    .filter(Number.isFinite);
  if (!numbers.length) return { currency, interval, text: raw };
  return {
    currency,
    min: numbers[0],
    max: numbers[1],
    interval,
    text: raw
  };
}

export function computeJobContentHash(job: Pick<NormalizedJob,
  'provider' | 'providerJobId' | 'company' | 'title' | 'description' | 'locations' | 'workMode'
> & Partial<Pick<NormalizedJob, 'compensation' | 'postedAt'>>): string {
  const stable = JSON.stringify({
    provider: job.provider,
    providerJobId: job.providerJobId,
    company: job.company.trim(),
    title: job.title.trim(),
    description: job.description.trim(),
    locations: [...job.locations].sort(),
    workMode: job.workMode,
    compensation: job.compensation,
    postedAt: job.postedAt
  });
  return createHash('sha256').update(stable).digest('hex');
}

export function normalizeProviderJob(source: JobSource, job: ProviderJob, now = new Date()): NormalizedJob {
  const canonicalUrl = canonicalizeJobUrl(job.url);
  const locations = normalizeLocations(job.locations);
  const base = {
    provider: source.provider,
    providerJobId: job.providerJobId.trim(),
    sourceId: source.sourceId,
    canonicalUrl,
    company: (job.company || source.company).trim(),
    title: job.title.trim(),
    description: String(job.description || '').trim(),
    locations,
    workMode: inferWorkMode(locations, job.workMode),
    compensation: job.compensation,
    postedAt: job.postedAt,
    firstSeenAt: now.toISOString(),
    lastSeenAt: now.toISOString(),
    status: 'active' as const
  };
  return parseNormalizedJob({ ...base, contentHash: computeJobContentHash(base) });
}
