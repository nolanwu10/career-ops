import test from 'node:test';
import { App } from 'aws-cdk-lib';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { developmentSources } from '../src/catalog.js';
import { ScannerStack } from './scanner-stack.js';

function template(): Template {
  const app = new App();
  return Template.fromStack(new ScannerStack(app, 'TestStack', { stage: 'dev' }));
}

test('stack provisions encrypted on-demand tables and canonical URL index', () => {
  const value = template();
  value.resourceCountIs('AWS::DynamoDB::Table', 8);
  value.hasResourceProperties('AWS::DynamoDB::Table', {
    BillingMode: 'PAY_PER_REQUEST',
    SSESpecification: { SSEEnabled: true }
  });
  value.hasResourceProperties('AWS::DynamoDB::Table', {
    GlobalSecondaryIndexes: Match.arrayWith([
      Match.objectLike({ IndexName: 'CanonicalUrlIndex' })
    ])
  });
  value.hasResourceProperties('AWS::DynamoDB::Table', {
    TimeToLiveSpecification: {
      AttributeName: 'expiresAt',
      Enabled: true
    }
  });
  value.hasResourceProperties('AWS::DynamoDB::Table', {
    StreamSpecification: { StreamViewType: 'NEW_AND_OLD_IMAGES' }
  });
  value.hasResourceProperties('AWS::DynamoDB::Table', {
    GlobalSecondaryIndexes: Match.arrayWith([
      Match.objectLike({ IndexName: 'JobRecommendationsIndex' })
    ])
  });
});

test('stack provisions scan queue, DLQ, worker, and one schedule per source', () => {
  const value = template();
  value.resourceCountIs('AWS::SQS::Queue', 5);
  value.resourceCountIs('AWS::Scheduler::Schedule', developmentSources.length);
  value.hasResourceProperties('AWS::Lambda::Function', {
    Runtime: 'nodejs22.x',
    Timeout: 120,
    MemorySize: 1024,
    ReservedConcurrentExecutions: 10
  });
  value.hasResourceProperties('AWS::Lambda::EventSourceMapping', {
    BatchSize: 1,
    FunctionResponseTypes: ['ReportBatchItemFailures']
  });
  value.hasResourceProperties('AWS::Lambda::EventSourceMapping', {
    StartingPosition: 'LATEST',
    BisectBatchOnFunctionError: true
  });
  value.hasResourceProperties('AWS::Scheduler::Schedule', {
    FlexibleTimeWindow: { Mode: 'FLEXIBLE', MaximumWindowInMinutes: 5 },
    Target: Match.objectLike({
      RetryPolicy: {
        MaximumEventAgeInSeconds: 3600,
        MaximumRetryAttempts: 5
      }
    })
  });
});

test('matching and enrichment workers have scoped data access and Bedrock invocation', () => {
  const value = template();
  value.resourceCountIs('AWS::Lambda::Function', 4);
  value.hasResourceProperties('AWS::IAM::Policy', {
    PolicyDocument: {
      Statement: Match.arrayWith([
        Match.objectLike({
          Action: 'bedrock:InvokeModel',
          Effect: 'Allow',
          Resource: '*'
        })
      ])
    }
  });
});

test('stack provisions alarms and scanner dashboard', () => {
  const value = template();
  value.resourceCountIs('AWS::CloudWatch::Alarm', 7);
  value.resourceCountIs('AWS::CloudWatch::Dashboard', 1);
});
